####Replication package
####Date: September 2017
####Author Rodrigo Morales
####Subject: This file describe the contents of the replication package
####Paper Titled: Efficient Refactoring Scheduling based on Partial Order Reduction
####Journal: JSS
####Contact: to rodrigo.morales2@acm.org

The replication package contains the following elements:

Fig3_QualityEvolutionoftheR		--- A folder containing csv files if the evolution of the metaheuristics used.  Time is given in ms., and quality is DI.
README.txt						--- This file.
Table10MedianCountOfRef			--- Contains a file for each algorithm-software system studied with the number of refactorings applied by type, of the 30 runs (The median was computed using R, by grouping the 30 independent runs).
Table7DesignImprovement			--- The detailed csv' files from the execution of each algorithm-software system of the 30 independent runs.
Table9ExecutionTime				--- The detailed csv' files with the execution times of each algorithm-software system of the 30 independent runs.
Table9RefactoringsApplied		--- A csv file containing the median of refactorings applied by algorithm-software.  It was generated from the files of folder "Table7DesignImprovement".


All statistical tests are generated in R using wilcox.test and cliff.delta packages over the files described above, when applicable.





